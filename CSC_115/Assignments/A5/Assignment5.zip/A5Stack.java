public class A5Stack<T> implements Stack<T> {
	
	private Node<T> head;

	public A5Stack() {
		// TODO: implement this
	}
	
	public void push(T v) {
		// TODO: implement this
	}
	
	public T pop() {
		// TODO: implement this	

		return null; // so it compiles
	}

	public T top() {
		// TODO: implement this	

		return null; // so it compiles
	}	
	
	public void popAll() {
		// TODO: implement this	
	}
	
	public boolean isEmpty() {
		// TODO: implement this	

		return false; // so it compiles
	}
	
}